stage_firewalld
=========

A role to deploy base Acclaris firewalld configurations to a newly provisioned RHEL7 server

Requirements
------------

Ansible 2.0

Role Variables
--------------
```
allowed_ports:
   - { port: "6556", proto: "tcp" }

allowed_service:
   - { srvsvc: "dhcpv6-client" , svcstate: "disabled" }
   - { srvsvc: "cockpit" , svcstate: "disabled" }
   - { srvsvc: "mdns" , svcstate: "disabled" }
   - { srvsvc: "samba-client" , svcstate: "disabled" }
   - { srvsvc: "ssh", svcstate: "enabled" }

```
Dependencies
------------

None

Example Syntax
----------------

ansible-playbook -i inventory playbook.yml -e target=hosts

Example Playbook
----------------
```
    - hosts: "{{ target }}"
      roles:
         - stage_firewalld

```
License
-------

None

Author Information
------------------

Randy Romero  
randy.romero@acclaris.com  
