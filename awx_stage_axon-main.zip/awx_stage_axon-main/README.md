awx_stage_axon
=========

Awx role to deploy axon agent

Requirements
------------

Requires BA repo assigned to host

Role Variables
--------------

twhost: tpaprdcowtwe01

twport: '5670'

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: username.rolename, x: 42 }

License
-------

None

Author Information
------------------

Randy Romero   
randy.romero@willistowerswatson.com
