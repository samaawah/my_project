deploy_sudoers
=========

```
This role is designed to deploy sudoers files for the following users/groups

USERS
-----
linux_admins  
nessus.service
unixsvc  

ROLES
----
wtw.ba.devops.onshore
wtw.ba.devops.standard

```

Requirements
------------

Ansible 2.0

Role Variables
--------------

```
hosts: "{{ target }}"

sudoers_core:
       - '001_linux_admins'
       - '001_unixsvc'

sudoers_dev:
       - '100_devops_role'

```


Dependencies
------------

None

Example Syntax 
----------------

To install core roles:
ansible-playbook -i inventory playbook.yml -e target=hostlist 

To install the devops role:
ansible-playbook -i inventory playbook.yml -e target=hostlist -e devops_sudo=true

Example Playbook
----------------
```
	- hosts: "{{ target }}"
	  gather_facts: True
	  become: True
	  roles:
	    - { role: deploy_sudoers,
	        when: ansible_os_family == "RedHat" and
		      ansible_distribution_major_version|int >= 5 }

```



License
-------

None

Author Information
------------------

Randy Romero  
randy.romero@willistowerswatson.com
