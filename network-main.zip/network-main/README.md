Joe rules.

No, Tom rules.