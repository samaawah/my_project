oel9_cis_l1_section1
=========

CIS L1 Section 1 Provisioning Role

Requirements
------------

```
ansible-galaxy collection install ansible.posix
```

Example Playbook
----------------

```
- hosts: "{{ target }}"
  gather_facts: True
  become: True
  roles:
    - oel9_cis_l1_section1
```

Author Information
------------------

Joe Hall | joseph.hall@wtwco.com
