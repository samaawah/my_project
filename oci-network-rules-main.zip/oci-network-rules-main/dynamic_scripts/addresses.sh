#!/bin/bash

# requires vendors.txt
# finds ips for url
# validates the entry is a somewhat valid ipv4 address
# adds /32 cidr notation
# wraps each entry in quotes
# converts newlines to commas

echo "locals {" > automation_team_vars.tf

for i in $(cat dynamic_scripts/vendors.txt) ; do
  vendor=$(echo $i | cut -d ":" -f 1)
  url=$(echo $i | cut -d ":" -f 2)
  ip_addresses=$(dig "${url}" -4 +short | grep -E '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | sed 's/$/\/32/g' | sed -e 's/^\|$/"/g' | sed -z 's/\n/,/g;s/,$/\n/')
  echo "  ${vendor} = [${ip_addresses}]" >> automation_team_vars.tf
done

echo "}" >> automation_team_vars.tf