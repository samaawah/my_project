AWX_PKI_CERT
=========

A role to deploy a PKI cert for a host on the INTERNAL domain.

Requirements
------------

None

Role Variables
--------------

pki_ca_host: pki-na1-12.internal.towerswatson.com
pki_ca_url: 'https://{{ pki_ca_host }}/certsrv'
pki_ca_referer: '{{ pki_ca_url }}/certrqxt.asp'
pki_ca_req_url: '{{ pki_ca_url }}/certfnsh.asp' 

ad_user: svc-pki-request-p
ad_pass: to be removed!


Dependencies
------------

None

License
-------

None

Author Information
------------------

System Engineering, Mar 2025
# get_pki_cert
