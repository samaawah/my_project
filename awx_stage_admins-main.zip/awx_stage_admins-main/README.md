awx_stage_admins
=========

Role to deploy user admin keys 

Requirements
------------

None

Role Variables
--------------

See vars file

Dependencies
------------

None

Example Playbook
----------------

License
-------

None

Author Information
------------------

Randy Romero   
randy.romero@willistowerswatson.com
