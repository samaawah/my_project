# oci_lab_access
 Lab access scripting for OCI
