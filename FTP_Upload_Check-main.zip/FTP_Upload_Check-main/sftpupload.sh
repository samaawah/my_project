for j in $(seq 1 10000); do
rm -f sftp_command.txt
        for i in $(seq 1 500); do
                dt=$(date "+%Y%m%d%H%M_%S")
                /usr/bin/cat /home/ACCLARISCORP/kishore.kamal/fupload/test > /home/ACCLARISCORP/kishore.kamal/fupload/file_int_${dt}_${i}_${j}
                echo put file_int_${dt}_${i}_${j} >> sftp_command.txt
                echo !date >> sftp_command.txt
        done
		echo bye >> sftp_command.txt
        sftp -i /home/ACCLARISCORP/kishore.kamal/fupload/test_prod_sftp.pem -P 10022 -b sftp_command.txt wtw.testuser@ashprdenlftp01
        sleep 60
done

