stage_checkmk
=========

A role to configure a newly staged server in check_mk.  

Requirements
------------

Ansible 2.0

Role Variables
--------------
```
monitorsite: tpa_linux

```
Dependencies
------------

None

Example Syntax
----------------

ansible-playbook -i inventory playbook.yml -e target=hosts

Example Playbook
----------------
```
    - hosts: "{{ target }}"
      roles:
         - stage_checkmk

```
License
-------

None

Author Information
------------------

Michael DiDato
michael.didato@willistowerswatson.com
