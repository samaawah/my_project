stage_installrpms
=========

A role to install rpms needed during staging of new hosts

Requirements
------------

Ansible 2.9 or higher

Role Variables
--------------

Set in the tasks/main.yml file

Dependencies
------------

None

Example Playbook
----------------
```
  - hosts: all
    roles:
      - stage_installrpms
```

License
-------

None

Author Information
------------------

Joe Hall
joe.hall@wtwco.com
