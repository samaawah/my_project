#!/bin/bash

HOST_NAME="ashprdcolmon01.acclariscorp.com"
SITE_NAME="ashburn"
API_URL="https://$HOST_NAME/$SITE_NAME/check_mk/api/1.0"

USERNAME="shutdown_startup"
PASSWORD="UQRONRRXTHVEQCVUAOCA"

SHUTDOWN_TIME=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
STARTUP_TIME=$(date -d "+50 hours" -u +"%Y-%m-%dT%H:%M:%SZ")

out=$(
  curl -k \
    --request POST \
    --write-out "\nxxx-status_code=%{http_code}\n" \
    --header "Authorization: Bearer $USERNAME $PASSWORD" \
    --header "Accept: application/json" \
    --header "Content-Type: application/json" \
    --data "{
          \"comment\": \"Scheduled Environment Shutdown\",
          \"downtime_type\": \"hostgroup\",
          \"end_time\": \"$STARTUP_TIME\",
          \"hostgroup_name\": \"EnterpriseStress\",
          \"start_time\": \"$SHUTDOWN_TIME\"
        }" \
    "$API_URL/domain-types/downtime/collections/host")

resp=$( echo "${out}" | grep -v "xxx-status_code" )
code=$( echo "${out}" | awk -F"=" '/^xxx-status_code/ {print $2}')

echo "$resp"

if [[ $code -lt 400 ]]; then
    echo "OK"
    exit 0
else
    echo "Request error"
    exit 1
fi