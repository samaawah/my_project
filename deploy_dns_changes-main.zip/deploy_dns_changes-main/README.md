deploy_dns_changes
=========

This role is used for changing dns records hosted on the Linux Acclaris name servers.

Requirements
------------

This role is to only be run on the Acclaris name primary and secondary name servers when dns changes are required  
The role does have some conditionals to try to ensure it doesn't run on any host other than what should be run
Only use the seo branch moving forward and include the JIRA in the commit messages

Role Variables
--------------

```
master_server: tpaprdcoldns01

slave_server: louprdcoldns01

common_zones:
  - acclarisbenefits.com
  - acclaris.com
  - acclaris.net
  - acclarisonline
  - bacbenefitsolutions.com
  - participantportal.com

public_only:
  - 163.136.128.in-addr.arpa
  - 180.81.192.in-addr.arpa
  - 181.81.192.in-addr.arpa

```

Dependencies
------------

None

Example Playbook
----------------
```

ansible-playbook -i $ROLEDIR/inventory $ROLEDIR/playbook.yaml -e "target=dnshosts"


- hosts: "{{ target }}"
  gather_facts: True
  become: True
  roles:
    - { role: deploy_dns_changes,
        when: (ansible_hostname|lower  == "tpaprdcoldns01" or
              ansible_hostname|lower  == "louprdcoldns01") and
              ansible_os_family == "RedHat" and
              ansible_distribution_major_version|int <= 7 }

```

License
-------

None

Author Information
------------------

```
Randy Romero
randy.romero@willistowerswatson.com

```

