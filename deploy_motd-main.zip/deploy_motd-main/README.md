motd
=========

Role used to propagate a standardized motd that contains basic host information.  
This role should typically be run after a succesful reboot after patching.

Requirements
------------

None

Role Variables
--------------

motd_files:  
  - issue  
  - issue.net  
  - motd  


Dependencies
------------

None

Example Playbook
----------------

    - hosts: "{{ target }}"  
      gather_facts: True  
      become: True  
      roles:  
        - { role: motd,  
            when: ansible_os_family == "RedHat" and  
                  ansible_distribution_major_version|int <= 7 }  


License
-------

BSD

Author Information
------------------

Randy Romero  
randy.romero@acclaris.com  

