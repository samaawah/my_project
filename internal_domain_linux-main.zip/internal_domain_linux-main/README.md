internal_domain_linux
=========

Ansible role intended to join servers to the internal domain, including DNS, SSSD, and NTP configurations.

How to run:
```
ansible-playbook --ask-vault-pass -i inventory -e target=all roles/internal_domain_linux/playbook.yml
```
Requirements
------------

- Set timeout=60 in your .ansible.cfg under [defaults] - large templates sometimes cause a timeout otherwise
- Run from an account with sudo permissions on the target VM
- Supports OEL/RHEL8 & 9
- Vault password to be saved in CyberArk

Role Variables
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:
```
---
- hosts: "{{ target }}"
  become: True
  roles:
    - internal_domain_linux
```

License
-------

BSD

Author Information
------------------

Joe Hall, Mar 2025
