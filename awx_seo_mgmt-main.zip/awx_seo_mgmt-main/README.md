AWX_SEO_MGMT
=========

This PROJECT is the base project for all SEO management playbooks and roles related to server management  
excluding provisioning and patching.  Ie.  DNS changes, password changes, audits, and or remdiations

Requirements
------------

Ansible 2.9 or higher   
Merges to master branch REQUIRE a pull request.



Author Information
------------------

Randy Romero  
randy.romero@willistowerswatson

