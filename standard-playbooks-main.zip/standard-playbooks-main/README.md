## Standard Playbooks ##

Use any of these playbook to ease work flow.

### To run for a hosts file ###
ansible-playbook -i inventoryfile playbook.yml

### For a specific server ###
ansible-playbook -i servername.acclariscorp.com, playbook.yml

## For Rhel8 instance complaining of /usr/bin/python not found ## 
ansible-playbook -i hostfile or servername.acclariscorp.com, playbook  --extra-vars 'ansible_python_interpreter=/usr/bin/python3'
