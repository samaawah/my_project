# cloud-init-scripts
cloud-init scripts used for provisioning and DR
