deploy_local_passwords
=========

A role designed to manage the passwords for the following users:   
     
root  
unixsvc  

Requirements
------------

Ansible 2.0 or higher
Vault password is stored in Secret server.
Passwords should be tested and validated to work before using this role to change them.  
Password should also be stored in the secretserver before changing.  

Role Variables
--------------

key_users:
   - { user: root, key: encrypted_password }
   - { user: unixsvc, key: encrypted_password }


Dependencies
------------

None

Example Syntax
----------------

ansible-playbook -i inventory playbook.yml -e target="foo" --ask-vault-pass 

Example Playbook
----------------
```


    - hosts: "{{ target }}"  
      gather_facts: True   
      become: True  
      roles:  
        - { role: deploy_local_passwords,  
            when: ansible_os_family == "RedHat" and  
                  ansible_distribution_major_version|int >= 5 }  
```

License
-------

None

Author Information
------------------

Randy Romero  
randy.romero@willistowerswatson.com

