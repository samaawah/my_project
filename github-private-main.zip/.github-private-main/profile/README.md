## BA Systems Engineering

### Helpful links:
- [Running Terraform Automation](https://kb.extendhealth.com/display/IN/GitHub+Actions)
- [OCI Lab Access](https://kb.extendhealth.com/display/IN/Developer+Lab+Access)
- Code Standards
